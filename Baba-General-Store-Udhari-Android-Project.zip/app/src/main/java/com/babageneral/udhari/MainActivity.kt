package com.babageneral.udhari

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: StoreDb
    private lateinit var content: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = StoreDb(this)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        scroll.addView(content)
        setContentView(scroll)
        render()
    }

    private fun render() {
        content.removeAllViews()
        val title = TextView(this).apply {
            text = "Baba General Store"
            textSize = 25f
            setTypeface(null, Typeface.BOLD)
        }
        content.addView(title)
        content.addView(TextView(this).apply {
            text = "उधारी और लेन-देन रजिस्टर  •  Offline mode"
            textSize = 15f
        })
        summary = TextView(this).apply {
            textSize = 18f
            setPadding(0, 22, 0, 18)
        }
        content.addView(summary)
        val add = Button(this).apply {
            text = "+ नया ग्राहक जोड़ें"
            setOnClickListener { addCustomerDialog() }
        }
        content.addView(add)
        val refresh = Button(this).apply {
            text = "↻ हिसाब अपडेट करें"
            setOnClickListener { render() }
        }
        content.addView(refresh)
        content.addView(TextView(this).apply {
            text = "ग्राहकों का हिसाब"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 22, 0, 10)
        })
        val customers = db.customers()
        var totalDue = 0.0
        customers.forEach { c ->
            val balance = db.balance(c.id)
            totalDue += balance
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            }
            card.addView(TextView(this).apply {
                text = c.name + if (c.phone.isNotBlank()) "  •  ${c.phone}" else ""
                textSize = 18f
                setTypeface(null, Typeface.BOLD)
            })
            card.addView(TextView(this).apply {
                text = "बाकी उधारी: ₹${money(balance)}"
                textSize = 17f
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(Button(this@MainActivity).apply {
                text = "उधार दें"
                setOnClickListener { transactionDialog(c.id, c.name, true) }
            })
            actions.addView(Button(this@MainActivity).apply {
                text = "जमा लें"
                setOnClickListener { transactionDialog(c.id, c.name, false) }
            })
            actions.addView(Button(this@MainActivity).apply {
                text = "WhatsApp"
                setOnClickListener { shareBalance(c.name, c.phone, balance) }
            })
            card.addView(actions)
            card.setOnClickListener { historyDialog(c.id, c.name) }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 12
            content.addView(card, lp)
        }
        summary.text = "कुल ग्राहक: ${customers.size}     कुल बाकी: ₹${money(totalDue)}"
        if (customers.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "अभी कोई ग्राहक नहीं है। ऊपर बटन दबाकर ग्राहक जोड़ें।"
                textSize = 16f
                setPadding(0, 12, 0, 12)
            })
        }
        content.addView(TextView(this).apply {
            text = "\nCloud backup: अगला सेटअप बाकी है। अभी आपका हिसाब इस फोन में सुरक्षित रहता है।"
            textSize = 13f
        })
    }

    private fun addCustomerDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val name = EditText(this).apply { hint = "ग्राहक का नाम" }
        val phone = EditText(this).apply {
            hint = "मोबाइल नंबर (वैकल्पिक)"
            inputType = 3
        }
        box.addView(name); box.addView(phone)
        AlertDialog.Builder(this).setTitle("नया ग्राहक")
            .setView(box)
            .setNegativeButton("रद्द", null)
            .setPositiveButton("सेव करें") { _, _ ->
                if (name.text.toString().trim().isNotEmpty()) {
                    db.addCustomer(name.text.toString().trim(), phone.text.toString().trim())
                    render()
                } else toast("ग्राहक का नाम लिखें")
            }.show()
    }

    private fun transactionDialog(id: Long, customer: String, isCredit: Boolean) {
        val amount = EditText(this).apply {
            hint = "रकम (₹)"
            inputType = 8194
        }
        val note = EditText(this).apply { hint = "विवरण (वैकल्पिक)" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(amount); addView(note)
        }
        AlertDialog.Builder(this)
            .setTitle(if (isCredit) "$customer को उधार दें" else "$customer से जमा लें")
            .setView(box).setNegativeButton("रद्द", null)
            .setPositiveButton("सेव करें") { _, _ ->
                val value = amount.text.toString().toDoubleOrNull()
                if (value == null || value <= 0) toast("सही रकम लिखें")
                else {
                    db.addTxn(id, if (isCredit) value else -value, note.text.toString())
                    render()
                }
            }.show()
    }

    private fun historyDialog(id: Long, customer: String) {
        val rows = db.history(id)
        val text = if (rows.isEmpty()) "अभी कोई लेन-देन नहीं है।" else rows.joinToString("\n\n") {
            "${it.date}\n${if (it.amount >= 0) "उधार" else "जमा"}: ₹${money(kotlin.math.abs(it.amount))}\n${it.note}"
        }
        AlertDialog.Builder(this).setTitle("$customer का पूरा हिसाब")
            .setMessage(text).setPositiveButton("ठीक है", null).show()
    }

    private fun shareBalance(name: String, phone: String, balance: Double) {
        val message = "Baba General Store\nग्राहक: $name\nबाकी उधारी: ₹${money(balance)}"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
            if (phone.isNotBlank()) putExtra("jid", phone.replace("+", "") + "@s.whatsapp.net")
            setPackage("com.whatsapp")
        }
        try { startActivity(intent) } catch (_: Exception) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message)
            }, "हिसाब शेयर करें"))
        }
    }

    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { db.close(); super.onDestroy() }
}

data class Customer(val id: Long, val name: String, val phone: String)
data class Txn(val date: String, val amount: Double, val note: String)
