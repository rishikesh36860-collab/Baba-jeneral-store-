package com.babageneral.udhari

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StoreDb(context: Context) : SQLiteOpenHelper(context, "baba_udhari.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE txns(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(customer_id) REFERENCES customers(id))")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addCustomer(name: String, phone: String) {
        writableDatabase.insert("customers", null, ContentValues().apply {
            put("name", name); put("phone", phone)
        })
    }

    fun customers(): List<Customer> {
        val out = mutableListOf<Customer>()
        readableDatabase.rawQuery("SELECT id,name,phone FROM customers ORDER BY name COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out.add(Customer(c.getLong(0), c.getString(1), c.getString(2)))
        }
        return out
    }

    fun addTxn(customerId: Long, amount: Double, note: String) {
        val date = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date())
        writableDatabase.insert("txns", null, ContentValues().apply {
            put("customer_id", customerId); put("amount", amount); put("note", note); put("created_at", date)
        })
    }

    fun balance(customerId: Long): Double {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM txns WHERE customer_id=?", arrayOf(customerId.toString())).use {
            return if (it.moveToFirst()) it.getDouble(0) else 0.0
        }
    }

    fun history(customerId: Long): List<Txn> {
        val out = mutableListOf<Txn>()
        readableDatabase.rawQuery("SELECT created_at,amount,note FROM txns WHERE customer_id=? ORDER BY id DESC", arrayOf(customerId.toString())).use { c ->
            while (c.moveToNext()) out.add(Txn(c.getString(0), c.getDouble(1), c.getString(2)))
        }
        return out
    }
}
